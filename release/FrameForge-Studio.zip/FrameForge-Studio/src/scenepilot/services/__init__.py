"""Core application services."""
