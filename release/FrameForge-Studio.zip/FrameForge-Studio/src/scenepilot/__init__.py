"""ScenePilot AI backend."""
