"""Provider adapters."""
